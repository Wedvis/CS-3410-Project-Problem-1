module Cards {
	requires javafx.controls;
	requires javafx.graphics;
	requires java.desktop;
	
	opens group_project to javafx.graphics, javafx.fxml;
}
